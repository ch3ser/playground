"""ReverseLab local MCP helpers."""

